# Bob

Simple - it roasts you based on your text messages. 